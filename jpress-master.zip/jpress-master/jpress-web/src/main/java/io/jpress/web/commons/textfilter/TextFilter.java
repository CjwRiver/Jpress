package io.jpress.web.commons.textfilter;

/**
 * @author michael yang (fuhai999@gmail.com)
 * @Date: 2020/1/5
 */
public interface TextFilter {

    public boolean check(String text);

}
