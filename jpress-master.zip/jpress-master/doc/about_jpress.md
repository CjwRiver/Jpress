# 关于JPress

### 1.JPress公众号

![](./images/jpress_qrcode.jpg)



### 2.关于JPress的相关文章

- [JPress模板开发视频教程.mp4](https://mp.weixin.qq.com/s/DZ0RQtpeVocdzs_h1bW9GA)
- [JPress 2019 新计划](https://mp.weixin.qq.com/s/OvEkHa9pL6vRnMLZNJ_0zg)
- [历时2年，JPress v1.0 正式版虽然发布了，但是作者想说的是...](https://mp.weixin.qq.com/s/raxE6tnR8gDYNjFMcFTBLg)
- [JPress 荣获 GVP，发布全新的精品主题祝贺](https://mp.weixin.qq.com/s/r6J5JvlG16WEe7PCuoxjZg)
- [JPress School 发布了](https://mp.weixin.qq.com/s/GbNv0xaK6jruWqTDJ_Ospw)
- [JPress开发路线图出炉，发力对接微信小程序...](https://mp.weixin.qq.com/s/n8xdzDPKacXHYVXfOLMhLQ)
- [JPress 1.0 发布了](https://mp.weixin.qq.com/s/N_bJIEz_Y52l--qj7f2sSg)