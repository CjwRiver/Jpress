DROP TABLE IF EXISTS `jpress_addon_message`
